const APP = (() => (
  {}
))();
